import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:syncfusion_flutter_charts/charts.dart';

class carbon extends StatefulWidget {
  @override
  _CarbonState createState() => _CarbonState();
}

class _CarbonState extends State<carbon> {
  List<ChartData> carbonIntensityData = [];
  bool isLoading = false;
  String errorMessage = '';
  String intensityStatus = 'LOW'; // Default status
  double nationalIntensity = 0.0; // To store the national intensity value

  // Fetch carbon intensity data from the API
  Future<void> fetchCarbonIntensityData() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      final url = Uri.parse('https://api.carbonintensity.org.uk/intensity');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List<dynamic> intensities = data['data'];

        // Extract the last 48 half-hour data and convert it to ChartData format
        List<ChartData> spots = [];
        for (int i = intensities.length - 48; i < intensities.length; i++) {
          if (i < 0) continue; // Ensure no out-of-bound errors

          final intensity = intensities[i]['intensity']['forecast'];  // Intensity in gCO₂/kWh
          final time = DateTime.parse(intensities[i]['from']); // Time in ISO 8601 format

          if (intensity != null && intensity is int) {
            // Use index as x-value for the time series plot
            spots.add(ChartData(i.toDouble(), intensity.toDouble()));
          }
        }

        // Set the national intensity value from the first data point (or choose another appropriate data point)
        nationalIntensity = intensities.isNotEmpty
            ? intensities[0]['intensity']['forecast'].toDouble()
            : 0.0;

        // Set intensity status based on threshold
        intensityStatus = nationalIntensity > 200 ? 'HIGH' : 'LOW';

        setState(() {
          carbonIntensityData = spots;
        });
      } else {
        throw Exception('Failed to load carbon intensity data');
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error fetching data: $e';
        carbonIntensityData = [];
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchCarbonIntensityData();  // Fetch data when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Carbon Buddy 🐼'),
        centerTitle: true,
        backgroundColor: Colors.pink[30],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Reload the data:',
                  style: TextStyle(fontSize: 16, color: Colors.black),
                ),
                IconButton(
                  icon: Icon(Icons.refresh, color: Colors.blueAccent),
                  onPressed: fetchCarbonIntensityData,  // Reload data on button press
                ),
              ],
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blueGrey[700],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blueAccent),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'National Carbon Intensity',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '${nationalIntensity.toStringAsFixed(2)} gCO₂/kWh',  // Dynamic national intensity value
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent,
                    ),
                  ),
                  Divider(color: Colors.white54),
                  Text(
                    'Carbon intensity is $intensityStatus!\nMaybe take a break and read a book instead 📚.',
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        intensityStatus,
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.blueAccent,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 24),
            Text(
              'National half-hourly carbon intensity for the current day:',
              style: TextStyle(fontSize: 16, color: Colors.black),
            ),
            SizedBox(height: 16),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : carbonIntensityData.isEmpty
                  ? Center(child: Text('No data available', style: TextStyle(color: Colors.white54)))
                  : Container(
                color: Colors.blueGrey[700],
                child: SfCartesianChart(
                  primaryXAxis: NumericAxis(
                    title: AxisTitle(text: 'Time (Half-Hour Intervals)', textStyle: TextStyle(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),  // Set label text color to white
                    axisLine: AxisLine(color: Colors.white),  // Set axis line color to white
                    minimum: 0,  // Start at 0
                    maximum: carbonIntensityData.isNotEmpty
                        ? carbonIntensityData.last.time
                        : 1,  // Set max to last data point
                    interval: 1,  // Interval of 1 for each half-hour block
                  ),
                  primaryYAxis: NumericAxis(
                    title: AxisTitle(text: 'gCO₂/kWh', textStyle: TextStyle(color: Colors.white)),
                    labelFormat: '{value}g',  // Label format for y-axis
                    labelStyle: TextStyle(color: Colors.white),  // Set label text color to white
                    axisLine: AxisLine(color: Colors.white),  // Set axis line color to white
                    minimum: 0,  // Start y-axis at 0
                    interval: 50,  // Set interval for y-axis
                  ),
                  series: <ChartSeries>[
                    LineSeries<ChartData, double>(
                      dataSource: carbonIntensityData,
                      xValueMapper: (ChartData data, _) => data.time,
                      yValueMapper: (ChartData data, _) => data.intensity,
                      color: Colors.yellow,  // Line color
                      markerSettings: MarkerSettings(isVisible: true),  // Show markers for visibility
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ChartData class to hold the data for the chart
class ChartData {
  final double time;
  final double intensity;

  ChartData(this.time, this.intensity);
}
