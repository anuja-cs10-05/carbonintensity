# carbon_intensity

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

Overview
Carbon Buddy 🐼 is a Flutter mobile application that helps users track and visualize the carbon intensity of the electricity grid in real-time. The application fetches data from the UK Carbon Intensity API, and displays the carbon intensity forecast (measured in grams of CO₂ per kWh) for the past 48 half-hour intervals. It also provides a color-coded status that indicates whether the current carbon intensity is low or high, helping users make more sustainable decisions.

The app includes an interactive chart that displays the carbon intensity over time. Users can easily refresh the data to get the latest carbon intensity values.

Features
Real-time Data: The app fetches the latest carbon intensity data from the UK Carbon Intensity API.
Carbon Intensity Chart: A line chart visualizing the carbon intensity for the last 48 half-hour intervals.
Dynamic Status: Displays whether the carbon intensity is LOW or HIGH based on the forecasted values.
Refresh Data: Users can manually refresh the data to get the latest values by pressing a button.
User-Friendly UI: Clean and simple design with a focus on user experience.
Dependencies
http: For making network requests to fetch data from the API.
syncfusion_flutter_charts: For rendering the interactive chart that displays the carbon intensity data over time.
To use this project, make sure to include these dependencies in your pubspec.yaml file.
